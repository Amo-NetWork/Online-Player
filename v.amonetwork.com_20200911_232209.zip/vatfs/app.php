<?php
/**
 * author : 忆云竹 < http://eyunzhu.com/ >
 * e-mail : support@eyunzhu.com
 * github : https://github.com/eyunzhu/vatfs
 * blog   : http://eyunzhu.com
 * QQ群   : 490993740
 * 欢迎交流使用本程序，但请保留版权
 */

return [
    "debug"                 => false,
    "default_module"        =>  "index",//默认模块
    "default_controller"    =>  "index",//默认控制器
    "default_method"        =>  "index",//默认方法

    "default_template" => "default",//默认模版
];