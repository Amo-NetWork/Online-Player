<?php
/**
 * eyz
 * Author: 忆云竹 （eyunzhu.com）
 * GitHub: https://github.com/eyunzhu/eyz
 */

return [
    // required
    'database_type' => '',
    'database_name' => '',
    'server'        => '',
    'username'      => '',
    'password'      => '',
    // [optional]
    'charset'       => 'utf8mb4',
    'port'          => 3306,
    'prefix'        => 'eyz_',
];