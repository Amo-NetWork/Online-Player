<?php
/**
 * eyz
 * Author: 忆云竹 （eyunzhu.com）
 * GitHub: https://github.com/eyunzhu/eyz
 */

return [
    "debug"                 => false,
    "default_module"        =>  "index",//默认模块
    "default_controller"    =>  "index",//默认控制器
    "default_method"        =>  "index",//默认方法

    "default_template" => "default",//默认模版
];