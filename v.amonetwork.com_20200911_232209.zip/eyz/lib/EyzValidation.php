<?php
/**
 * eyz
 * Author: 忆云竹 （eyunzhu.com）
 * GitHub: https://github.com/eyunzhu/eyz
 */
namespace eyz\lib;
use WebGeeker\Validation\Validation;
class EyzValidation extends Validation
{

}