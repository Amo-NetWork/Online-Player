<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* player.html */
class __TwigTemplate_05e3c0eba5073cb88b02d69f33c54f292d6e2ca19e18acb55a80d7c587fdc9cb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <title>";
        // line 4
        echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4["title"] ?? null) : null), "html", null, true);
        echo "-播放器</title>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"keywords\" content=\"";
        // line 7
        echo twig_escape_filter($this->env, (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = (($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["meta"] ?? null) : null)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144["keywords"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"description\" content=\"";
        // line 8
        echo twig_escape_filter($this->env, (($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4["meta"] ?? null) : null)) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002["description"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"author\" content=\"阿莫\" />
    <meta name=\"copyright\" content=\"Copyright 2020 阿莫 All rights Reserved\" />
    <link rel=\"shortcut icon\" href=\"favicon.ico\" />

    <link href=\"/static/bootstrap/dist/css/bootstrap.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/style-v.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/video-js.min.css\">
    <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/DPlayer.min.css\">

    <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/DPlayer.min.js\"></script>
    <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/hls.min.js\"></script>
    <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/sweetalert.min.js\"></script>
</head>
<body>
    <!--顶部导航-->
    <nav class=\"navbar navbar-expand-lg navbar-dark shadow-sm rounded nice-nav\">
        <div class=\"container\"><a class=\"navbar-dark logo\" href=\"/\" style=\"color: #000000;\">
            <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, (($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666["logo"] ?? null) : null), "html", null, true);
        echo "\" class=\"mr-2\">";
        echo twig_escape_filter($this->env, (($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e["title"] ?? null) : null), "html", null, true);
        echo "</a>
            ";
        // line 27
        if (0 === twig_compare((($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = (($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136["navRight"] ?? null) : null)) && is_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52) || $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 instanceof ArrayAccess ? ($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52["status"] ?? null) : null), true)) {
            // line 28
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, (($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 = (($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9) || $__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 instanceof ArrayAccess ? ($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9["navRight"] ?? null) : null)) && is_array($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386) || $__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 instanceof ArrayAccess ? ($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386["url"] ?? null) : null), "html", null, true);
            echo "\" target=\"_blank\">";
            echo twig_escape_filter($this->env, (($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = (($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f) || $__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f instanceof ArrayAccess ? ($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f["navRight"] ?? null) : null)) && is_array($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae) || $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae instanceof ArrayAccess ? ($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae["name"] ?? null) : null), "html", null, true);
            echo "</a>
            ";
        }
        // line 30
        echo "        </div>
    </nav>
    <div class=\"container\">
        <div class=\"mt-2\">
            ";
        // line 34
        echo twig_escape_filter($this->env, (($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40) || $__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 instanceof ArrayAccess ? ($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40["title"] ?? null) : null), "html", null, true);
        echo "-播放器<span id=\"play-title\" class=\"pl-2\"></span>
        </div>
        <div class=\"mt-2\" style=\"width:100%;position:relative;padding-bottom:56.25%;height: 0;\">
            <div id=\"dplayer\" style=\"position: absolute;top:0;left: 0;width: 100%;height: 100%\"></div>
        </div>
        <div class=\"row\" >
            <div class=\"col-12 py-0\" style=\"padding-top:0 !important\">
                <div class=\"input-group my-1\">
                    <input id=\"video-url\" required name=\"play\" type=\"text\" class=\"form-control nice\" placeholder=\"输入 M3U8 URL 地址\"
                           value=\"\" aria-describedby=\"button-addon2\">
                    <div class=\"input-group-append\">
                        <button id=\"play-url\" class=\"btn btn-dark px-1 play border-0\" type=\"button\"><img src=\"";
        // line 45
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/play-v.png\"
                                                                                                         height=\"24\"></button>
                    </div>
                </div>
            </div>
        </div>
        <!--欢迎交流使用 请勿删除版权-->
        <p class=\"mt-4 mb-3 text-muted text-right\">
            Powered By <a href=\"https://github.com/Amo-NetWork/Online-Player\" class=\"text-muted\" target=\"_blank\">Amo-Online-Player</a>.
            Copyright 2020 <a href=\"https://amonetwork.com\" class=\"text-muted\" target=\"_blank\">Amo_NetWork</a> All rights Reserved.
        </p>
    </div>
</body>
<script src=\"";
        // line 58
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/jquery2.1.4.min.js\"></script>
<script src=\"";
        // line 59
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/common.js\"></script>
<script>
    ";
        // line 61
        if (0 === twig_compare(($context["url"] ?? null), "")) {
            // line 62
            echo "    swal(
        '请输入播放地址',
        '播放地址不可为空',
        'error'
    );
    ";
        }
        // line 68
        echo "    var playListId = 0;
    \$(\"#playList0\").removeClass(\"btn btn-info\");
    \$(\"#playList0\").addClass(\"btn btn-primary\");

    dp= new DPlayer({
        container: document.getElementById('dplayer'),
        autoplay: true,
        theme: '#FADFA3',
        loop: true,
        lang: 'zh-cn',
        screenshot: true,
        hotkey: true,
        preload: 'auto',
        logo: '";
        // line 81
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/ysqss.ico',
        volume: 0.7,
        mutex: true,
        video: {
            url: \"";
        // line 85
        echo twig_escape_filter($this->env, ($context["url"] ?? null), "html", null, true);
        echo "\",
            type: 'auto'
        },
        subtitle: {
            url: \"";
        // line 89
        echo twig_escape_filter($this->env, (($context["__TMPL__"] ?? null) . "/static/css/sdetail.v?"), "html", null, true);
        echo "\"+Date.parse(new Date()),
            type: 'webvtt',
            fontSize: '25px',
            bottom: '7%',
            color: '#b7daff',
        },
        contextmenu: [
            {
                text: '阿莫',
                link: 'https://amonetwork.com'
            },
        ],
        highlight: [
            {
                time: 200,
                text: '歡迎使用影視全搜索'
            },
            {
                time: 1000,
                text: '关注官方網站:Amo-NetWork'
            }
        ]
    });
    dp.on('waiting', function() {
        \$(\"#play-title\").text('加载缓慢请稍等...');
    });
    dp.on('playing', function() {
        \$(\"#play-title\").text('正在播放');
    });
    dp.on('pause', function() {
        \$(\"#play-title\").text('播放暂停');
    });
    dp.play();
    dp.subtitle.show()
    function play(url, name, id) {
        \$(\"#play-title\").text(name);
        \$(\"#play-titles\").text(name);

        \$(\"#playList\" + playListId).removeClass(\"btn btn-primary\");
        \$(\"#playList\" + playListId).addClass(\"btn btn-info\");

        playListId = id;
        playUrl = (url);
        console.log('playUrl',playUrl)
        dp.switchVideo({
            url: playUrl,
        });
        setTimeout(function() {
            dp.play();
            //dp.subtitle.hide();
        }, 200);

        \$(\"#playList\" + id).removeClass(\"btn btn-info\");
        \$(\"#playList\" + id).addClass(\"btn btn-primary\");
    }

    \$(\"#play-url\").click(function(){
        \$(\"#play-title\").text('播放自定义链接');
        \$(\"#play-titles\").text('');
        console.log(\$(\"#video-url\").val());
        dp.switchVideo({
            url: \$(\"#video-url\").val(),
        });
        setTimeout(function() {
            dp.play();dp.subtitle.hide();
        }, 200);
    });

</script>
</html>";
    }

    public function getTemplateName()
    {
        return "player.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  191 => 89,  184 => 85,  177 => 81,  162 => 68,  154 => 62,  152 => 61,  147 => 59,  143 => 58,  127 => 45,  113 => 34,  107 => 30,  99 => 28,  97 => 27,  91 => 26,  82 => 20,  78 => 19,  74 => 18,  69 => 16,  65 => 15,  61 => 14,  52 => 8,  48 => 7,  42 => 4,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "player.html", "/www/wwwroot/v.amonetwork.com/public/view/vatfs/default/index/index/player.html");
    }
}
