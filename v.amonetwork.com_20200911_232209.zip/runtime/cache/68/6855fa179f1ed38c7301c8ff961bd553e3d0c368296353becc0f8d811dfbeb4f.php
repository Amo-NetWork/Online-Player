<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html */
class __TwigTemplate_28e6b6d5940f6c7c557569b30b65cbed7f94adde593cd1f7f2a77d6547956100 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!--
 * author : 忆云竹 < http://eyunzhu.com/ >
 * e-mail : support@eyunzhu.com
 * github : https://github.com/eyunzhu/vatfs
 * blog   : http://eyunzhu.com
 * QQ群   : 490993740
 * 欢迎交流使用本程序，但请保留版权
-->
<!DOCTYPE html>
<html lang=\"en\">
<head>
    <title>";
        // line 12
        echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4["title"] ?? null) : null), "html", null, true);
        echo "</title>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"keywords\" content=\"";
        // line 15
        echo twig_escape_filter($this->env, (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = (($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["meta"] ?? null) : null)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144["keywords"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"description\" content=\"";
        // line 16
        echo twig_escape_filter($this->env, (($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4["meta"] ?? null) : null)) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002["description"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"author\" content=\"忆云竹\" />
    <meta name=\"copyright\" content=\"Copyright 2019 忆云竹 All rights Reserved\" />
    <link rel=\"shortcut icon\" href=\"favicon.ico\" />

    <link href=\"/static/bootstrap/dist/css/bootstrap.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/style-v.css\">

    <script src=\"";
        // line 24
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/jquery2.1.4.min.js\"></script>
    <script src=\"";
        // line 25
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/sweetalert.min.js\"></script>

</head>
<body>
<!--顶部导航-->
<nav class=\"navbar navbar-expand-lg navbar-dark shadow-sm rounded nice-nav\">
    <div class=\"container\"><a class=\"navbar-dark logo\" href=\"/\" style=\"color: #000000;\">
        <img  src=\"";
        // line 32
        echo twig_escape_filter($this->env, (($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666["logo"] ?? null) : null), "html", null, true);
        echo "\" class=\"mr-2\">";
        echo twig_escape_filter($this->env, (($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e["title"] ?? null) : null), "html", null, true);
        echo "</a>
        ";
        // line 33
        if (0 === twig_compare((($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = (($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136["navRight"] ?? null) : null)) && is_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52) || $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 instanceof ArrayAccess ? ($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52["status"] ?? null) : null), true)) {
            // line 34
            echo "        <a href=\"";
            echo twig_escape_filter($this->env, (($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 = (($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9) || $__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 instanceof ArrayAccess ? ($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9["navRight"] ?? null) : null)) && is_array($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386) || $__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 instanceof ArrayAccess ? ($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386["url"] ?? null) : null), "html", null, true);
            echo "\" target=\"_blank\">";
            echo twig_escape_filter($this->env, (($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = (($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f) || $__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f instanceof ArrayAccess ? ($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f["navRight"] ?? null) : null)) && is_array($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae) || $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae instanceof ArrayAccess ? ($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae["name"] ?? null) : null), "html", null, true);
            echo "</a>
        ";
        }
        // line 36
        echo "    </div>
</nav>
<div class=\"container\">
    <form action=\"/admin\" method=\"post\" onsubmit=\"return judge()\">
        <div class=\"input-group mb-2 mt-3\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">logo</span></div>
            <input id='logoInput'  type=\"file\" accept=\"image/png,image/gif,image/jpeg\" onchange=\"upload()\"
                    style=\"overflow: hidden;width: 0.1px;height: 0.1px;opacity: 0;overflow: hidden;position: absolute;z-index: -1;\"/>
            <input name=\"logo\" id=\"logo\" type=\"text\" hidden value=\"";
        // line 44
        echo twig_escape_filter($this->env, (($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40) || $__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 instanceof ArrayAccess ? ($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40["logo"] ?? null) : null), "html", null, true);
        echo "\">
            <label for=\"logoInput\">
                <img id=\"logoImg\" src=\"";
        // line 46
        echo twig_escape_filter($this->env, (($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f) || $__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f instanceof ArrayAccess ? ($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f["logo"] ?? null) : null), "html", null, true);
        echo "\" style=\"height:calc(1.5em + .75rem + 2px);padding-left:20px;\">
                <span style=\"margin-left:10px;font-size:12px;\">点击图片上传</span>
            </label>
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">title</span></div>
            <input name=\"title\" type=\"text\" class=\"form-control\" value=\"";
        // line 52
        echo twig_escape_filter($this->env, (($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760) || $__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 instanceof ArrayAccess ? ($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760["title"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">keywords</span></div>
            <input name=\"keywords\" type=\"text\" class=\"form-control\" value=\"";
        // line 56
        echo twig_escape_filter($this->env, (($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce = (($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b) || $__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b instanceof ArrayAccess ? ($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b["meta"] ?? null) : null)) && is_array($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce) || $__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce instanceof ArrayAccess ? ($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce["keywords"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">description</span></div>
            <input name=\"description\" type=\"text\" class=\"form-control\" value=\"";
        // line 60
        echo twig_escape_filter($this->env, (($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c = (($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972) || $__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972 instanceof ArrayAccess ? ($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972["meta"] ?? null) : null)) && is_array($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c) || $__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c instanceof ArrayAccess ? ($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c["description"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">searchTips</span></div>
            <input name=\"searchTips\" type=\"text\" class=\"form-control\" value=\"";
        // line 64
        echo twig_escape_filter($this->env, (($__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216) || $__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216 instanceof ArrayAccess ? ($__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216["searchTips"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">siteDescribe</span></div>
            <input name=\"siteDescribe\" type=\"text\" class=\"form-control\" value=\"";
        // line 68
        echo twig_escape_filter($this->env, (($__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0) || $__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0 instanceof ArrayAccess ? ($__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0["siteDescribe"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">searchApi</span></div>
            <input name=\"searchApi\" type=\"text\" class=\"form-control\" value=\"";
        // line 72
        echo twig_escape_filter($this->env, (($__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c) || $__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c instanceof ArrayAccess ? ($__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c["searchApi"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">detailApi</span></div>
            <input name=\"detailApi\" type=\"text\" class=\"form-control\" value=\"";
        // line 76
        echo twig_escape_filter($this->env, (($__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f) || $__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f instanceof ArrayAccess ? ($__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f["detailApi"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">navRight</span></div>
            <input name=\"navRight\" type=\"text\" class=\"form-control\" value=\"";
        // line 80
        echo twig_escape_filter($this->env, ($context["navRight"] ?? null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">link</span></div>
            <input name=\"link\" type=\"text\" class=\"form-control\" value=\"";
        // line 84
        echo twig_escape_filter($this->env, ($context["link"] ?? null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">user</span></div>
            <input name=\"user\" id=\"user\" type=\"text\" class=\"form-control\" value=\"";
        // line 88
        echo twig_escape_filter($this->env, (($__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc) || $__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc instanceof ArrayAccess ? ($__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc["user"] ?? null) : null), "html", null, true);
        echo "\" >
        </div>
        <div class=\"input-group mb-2\">
            <div class=\"input-group-prepend\"><span class=\"input-group-text\">password</span></div>
            <input name=\"password\" id=\"password\" type=\"password\" class=\"form-control\" placeholder=\"填则修改密码\" >
        </div>
        <div style=\"text-align:center;\">
            <button type=\"submit\" class=\"btn btn-primary\">修改</button>
            <button type=\"button\" onclick=\"loginOut()\" class=\"btn btn-primary\">登出</button>
        </div>
    </form>
    <!--欢迎交流使用 请勿删除版权-->
    <p class=\"mt-4 mb-3 text-muted\">
        Powered By <a href=\"https://github.com/eyunzhu/vatfs\" class=\"text-muted\" target=\"_blank\">vatfs</a>.
        Copyright 2019 <a href=\"http://eyunzhu.com\" class=\"text-muted\" target=\"_blank\">忆云竹</a> All rights Reserved.
    </p>
</div>
</body>
<script>
    function upload() {
        let file = \$(\"#logoInput\")[0].files[0];//e.target.files[0];
        let param = new FormData(); //创建form对象
        param.append('file', file); //通过append向form对象添加数据
        \$.ajax({
            url:'/index/index/uploadFile',
            type:'post',
            data: param,
            contentType: false,
            processData: false,
            success:function(e){
                e = JSON.parse(e);
                \$(\"#logoImg\").attr('src',e.data);
                \$(\"#logo\").val(e.data)
            }
        })
    }
    function judge() {
        userName = \$(\"#user\").val();
        passWord = \$(\"#password\").val();
        if(userName.length >=5 && (passWord.length>=5 || passWord.length==0)){
            return true;
        }else {
            swal(
                '登陆失败',
                '账号密码不得少于5位',
                'warning'
            );
            return false;
        }
    }
    function loginOut() {
        window.location.href = '/admin/index/LoginOut';
    }
</script>

</html>";
    }

    public function getTemplateName()
    {
        return "index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  191 => 88,  184 => 84,  177 => 80,  170 => 76,  163 => 72,  156 => 68,  149 => 64,  142 => 60,  135 => 56,  128 => 52,  119 => 46,  114 => 44,  104 => 36,  96 => 34,  94 => 33,  88 => 32,  78 => 25,  74 => 24,  69 => 22,  60 => 16,  56 => 15,  50 => 12,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.html", "/www/wwwroot/v.amonetwork.com/public/view/vatfs/default/admin/index/index.html");
    }
}
