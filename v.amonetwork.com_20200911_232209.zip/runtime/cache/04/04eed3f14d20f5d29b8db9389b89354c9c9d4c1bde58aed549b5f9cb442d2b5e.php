<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* index.html */
class __TwigTemplate_0dd14797cdf7d66797b45eca3117816ff11f90944dfaa135b445b35f7d9061f6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <title>";
        // line 4
        echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4["title"] ?? null) : null), "html", null, true);
        echo "</title>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"keywords\" content=\"";
        // line 7
        echo twig_escape_filter($this->env, (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = (($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["meta"] ?? null) : null)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144["keywords"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"description\" content=\"";
        // line 8
        echo twig_escape_filter($this->env, (($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4["meta"] ?? null) : null)) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002["description"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"author\" content=\"阿莫\" />
    <meta name=\"copyright\" content=\"Copyright 2020 阿莫 All rights Reserved\" />
    <link rel=\"shortcut icon\" href=\"favicon.ico\" />

    <link href=\"/static/bootstrap/dist/css/bootstrap.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/style-v.css\">
    <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/sweetalert.min.js\"></script>
    <!-- swiper -->
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/jquery2.1.4.min.js\"></script>
    <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/swiperTab.js\"></script>
    <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/swiperTab.css\"/>

</head>
<body>
    <!--顶部导航-->
    <nav class=\"navbar navbar-expand-lg navbar-dark shadow-sm rounded nice-nav\">
        <div class=\"container\"><a class=\"navbar-dark logo\" href=\"/\" style=\"color: #000000;\">
            <img src=\"";
        // line 26
        echo twig_escape_filter($this->env, (($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666["logo"] ?? null) : null), "html", null, true);
        echo "\" class=\"mr-2\">";
        echo twig_escape_filter($this->env, (($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e["title"] ?? null) : null), "html", null, true);
        echo "</a>
            ";
        // line 27
        if (0 === twig_compare((($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = (($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136["navRight"] ?? null) : null)) && is_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52) || $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 instanceof ArrayAccess ? ($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52["status"] ?? null) : null), true)) {
            // line 28
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, (($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 = (($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9) || $__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 instanceof ArrayAccess ? ($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9["navRight"] ?? null) : null)) && is_array($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386) || $__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 instanceof ArrayAccess ? ($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386["url"] ?? null) : null), "html", null, true);
            echo "\" target=\"_blank\">";
            echo twig_escape_filter($this->env, (($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = (($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f) || $__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f instanceof ArrayAccess ? ($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f["navRight"] ?? null) : null)) && is_array($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae) || $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae instanceof ArrayAccess ? ($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae["name"] ?? null) : null), "html", null, true);
            echo "</a>
            ";
        }
        // line 30
        echo "        </div>
    </nav>
    <div class=\"container\">
        <!--搜索框-->
        <form action=\"search\" method=\"get\">
            <div class=\"row\">
                <div class=\"col-12 py-3\">
                    <div class=\"input-group my-3\">
                        <input id=\"input-kw\" required name=\"kw\" type=\"text\" class=\"form-control nice\" placeholder=\"";
        // line 38
        echo twig_escape_filter($this->env, (($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40) || $__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 instanceof ArrayAccess ? ($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40["searchPlaceholder"] ?? null) : null), "html", null, true);
        echo "\" aria-describedby=\"button-addon2\">
                        <div class=\"input-group-append\"><button class=\"btn btn-dark px-1 play border-0\" type=\"submit\"><img src=\"";
        // line 39
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/search.png\"height=\"24\"></button></div>
                    </div>
                </div>
            </div>
        </form>
        <div>
            <h5 style=\"color:#333\">";
        // line 45
        echo twig_escape_filter($this->env, (($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f) || $__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f instanceof ArrayAccess ? ($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f["title"] ?? null) : null), "html", null, true);
        echo "</h5>
            <div class=\"row\">
                <div class=\"col\">&emsp;&emsp;
                    ";
        // line 49
        echo "                    ";
        echo (($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760) || $__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 instanceof ArrayAccess ? ($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760["siteDescribe"] ?? null) : null);
        echo "
                    ";
        // line 51
        echo "                </div>
            </div>
        </div>
        <!--电影搜索排行榜-->
        ";
        // line 55
        if (0 === twig_compare((($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce) || $__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce instanceof ArrayAccess ? ($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce["isShowSearchRanking"] ?? null) : null), true)) {
            // line 56
            echo "        <span style=\"border-left: 4px solid #993366;padding-left: 5px;\">搜索排行榜</span>
        <div class=\"swiper-container swiper1\">
            <div class=\"swiper-wrapper\">
                ";
            // line 59
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["rank"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["v"]) {
                // line 60
                echo "                <div class=\"swiper-slide ";
                echo ((twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 60)) ? ("selected") : (""));
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["v"], "name", [], "any", false, false, false, 60), "html", null, true);
                echo "</div>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 62
            echo "            </div>
        </div>
        <div class=\"swiper-container swiper2\">
            <div class=\"swiper-wrapper\" style=\"height: 600px;\">
                ";
            // line 66
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["rank"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["v"]) {
                // line 67
                echo "                <div class=\"swiper-slide swiper-no-swiping\" style=\"width: 290px;\">
                    <div class=\"row\">
                        ";
                // line 69
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["v"], "data", [], "any", false, false, false, 69));
                foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                    // line 70
                    echo "                        <div class=\"col-md-2 col-6\"
                             style=\"white-space:nowrap;word-break:keep-all;text-overflow:ellipsis;overflow:hidden;\">
                            <span onclick=\"doSearch('";
                    // line 72
                    echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                    echo "')\" style=\"color:#007bff;\">";
                    echo twig_escape_filter($this->env, $context["key"], "html", null, true);
                    echo " <span
                                    style=\"color:#336600;\">";
                    // line 73
                    echo twig_escape_filter($this->env, $context["value"], "html", null, true);
                    echo "</span></span>
                        </div>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 76
                echo "                    </div>
                </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 79
            echo "            </div>
        </div>
        ";
        }
        // line 82
        echo "
        <!--直播源-->
        ";
        // line 84
        if (0 === twig_compare((($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b) || $__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b instanceof ArrayAccess ? ($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b["isShowLive"] ?? null) : null), true)) {
            // line 85
            echo "        <span style=\"border-left: 4px solid #993366;padding-left: 5px;\">直播源</span>
        <div class=\"swiper-container swiper11\">
            <div class=\"swiper-wrapper\">
                ";
            // line 88
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["live"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["v"]) {
                // line 89
                echo "                <div class=\"swiper-slide ";
                echo ((twig_get_attribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 89)) ? ("selected") : (""));
                echo "\">";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["v"], "name", [], "any", false, false, false, 89), "html", null, true);
                echo "</div>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 91
            echo "            </div>
        </div>
        <div class=\"swiper-container swiper22\">
            <div class=\"swiper-wrapper\" style=\"height: 600px;\">
                ";
            // line 95
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["live"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["v"]) {
                // line 96
                echo "                <div class=\"swiper-slide swiper-no-swiping\" style=\"width: 290px;\">
                    <div class=\"row\">
                        ";
                // line 98
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, $context["v"], "data", [], "any", false, false, false, 98));
                foreach ($context['_seq'] as $context["key"] => $context["value"]) {
                    // line 99
                    echo "                        <div class=\"col-md-2 col-6\"
                             style=\"white-space:nowrap;word-break:keep-all;text-overflow:ellipsis;overflow:hidden;\">
                            <a href=\"player?url=";
                    // line 101
                    echo twig_escape_filter($this->env, (($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c = $context["value"]) && is_array($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c) || $__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c instanceof ArrayAccess ? ($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c["url"] ?? null) : null), "html", null, true);
                    echo "\" target=\"_blank\">";
                    echo twig_escape_filter($this->env, (($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972 = $context["value"]) && is_array($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972) || $__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972 instanceof ArrayAccess ? ($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972["name"] ?? null) : null), "html", null, true);
                    echo "</a>
                        </div>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['key'], $context['value'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 104
                echo "                    </div>
                </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['v'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 107
            echo "            </div>
        </div>
        ";
        }
        // line 110
        echo "        <!--欢迎交流使用 请勿删除版权-->
        <p class=\"mt-4 mb-3 text-muted text-right\">
            Powered By <a href=\"https://github.com/Amo-NetWork/Online-Player\" class=\"text-muted\" target=\"_blank\">Amo-Online-Player</a>.
            Copyright 2020 <a href=\"https://amonetwork.com\" class=\"text-muted\" target=\"_blank\">Amo_NetWork</a> All rights Reserved.
        </p>
    </div>
</body>
<script src=\"";
        // line 117
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/index.js\"></script>
<script src=\"";
        // line 118
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/common.js\"></script>
</html>";
    }

    public function getTemplateName()
    {
        return "index.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  343 => 118,  339 => 117,  330 => 110,  325 => 107,  317 => 104,  306 => 101,  302 => 99,  298 => 98,  294 => 96,  290 => 95,  284 => 91,  265 => 89,  248 => 88,  243 => 85,  241 => 84,  237 => 82,  232 => 79,  224 => 76,  215 => 73,  209 => 72,  205 => 70,  201 => 69,  197 => 67,  193 => 66,  187 => 62,  168 => 60,  151 => 59,  146 => 56,  144 => 55,  138 => 51,  133 => 49,  127 => 45,  118 => 39,  114 => 38,  104 => 30,  96 => 28,  94 => 27,  88 => 26,  78 => 19,  74 => 18,  70 => 17,  65 => 15,  61 => 14,  52 => 8,  48 => 7,  42 => 4,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "index.html", "/www/wwwroot/v.amonetwork.com/public/view/vatfs/default/index/index/index.html");
    }
}
