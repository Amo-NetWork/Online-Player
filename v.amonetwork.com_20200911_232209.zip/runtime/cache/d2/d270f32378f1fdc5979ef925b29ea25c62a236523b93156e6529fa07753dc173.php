<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* login.html */
class __TwigTemplate_35c23fd5a01e26822372efc1cec9616f0021542f6b7a89465af239963a4ea189 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!--
 * author : 忆云竹 < http://eyunzhu.com/ >
 * e-mail : support@eyunzhu.com
 * github : https://github.com/eyunzhu/vatfs
 * blog   : http://eyunzhu.com
 * QQ群   : 490993740
 * 欢迎交流使用本程序，但请保留版权
-->
<!DOCTYPE html>
<html lang=\"en\">
<head>
    <title>";
        // line 12
        echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4["title"] ?? null) : null), "html", null, true);
        echo "</title>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"keywords\" content=\"";
        // line 15
        echo twig_escape_filter($this->env, (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = (($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["meta"] ?? null) : null)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144["keywords"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"description\" content=\"";
        // line 16
        echo twig_escape_filter($this->env, (($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4["meta"] ?? null) : null)) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002["description"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"author\" content=\"忆云竹\" />
    <meta name=\"copyright\" content=\"Copyright 2019 忆云竹 All rights Reserved\" />
    <link rel=\"shortcut icon\" href=\"favicon.ico\" />

    <link href=\"/static/bootstrap/dist/css/bootstrap.css\" rel=\"stylesheet\" >
    <link rel=\"stylesheet\" href=\"";
        // line 22
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/style-v.css\">
    <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/sweetalert.min.js\"></script>
</head>
<body>
    <!--顶部导航-->
    <nav class=\"navbar navbar-expand-lg navbar-dark shadow-sm rounded nice-nav\">
        <div class=\"container\"><a class=\"navbar-dark logo\" href=\"/\" style=\"color: #000000;\">
            <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, (($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666["logo"] ?? null) : null), "html", null, true);
        echo "\" class=\"mr-2\">";
        echo twig_escape_filter($this->env, (($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e["title"] ?? null) : null), "html", null, true);
        echo "</a>
            ";
        // line 30
        if (0 === twig_compare((($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = (($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136["navRight"] ?? null) : null)) && is_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52) || $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 instanceof ArrayAccess ? ($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52["status"] ?? null) : null), true)) {
            // line 31
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, (($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 = (($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9) || $__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 instanceof ArrayAccess ? ($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9["navRight"] ?? null) : null)) && is_array($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386) || $__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 instanceof ArrayAccess ? ($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386["url"] ?? null) : null), "html", null, true);
            echo "\" target=\"_blank\">";
            echo twig_escape_filter($this->env, (($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = (($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f) || $__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f instanceof ArrayAccess ? ($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f["navRight"] ?? null) : null)) && is_array($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae) || $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae instanceof ArrayAccess ? ($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae["name"] ?? null) : null), "html", null, true);
            echo "</a>
            ";
        }
        // line 33
        echo "        </div>
    </nav>
    <div class=\"container-fluid mt-5 text-center\">
        <form id=\"loginForm\" class=\"form-signin\" method=\"post\" action=\"/admin/index/login\" onsubmit=\"return judge()\" >
            <div class=\"row\">
                <div class=\"col-sm-8 offset-sm-2 col-md-4 offset-md-4 mt-5\">
                    <h1 class=\"h3 mb-3 font-weight-normal\">管理后台登陆</h1>
                    <label for=\"inputUserName\" class=\"sr-only\">User name</label>
                    <input type=\"Text\" id=\"inputUserName\" name=\"userName\" class=\"form-control \" placeholder=\"User name\" required autofocus>
                    <label for=\"inputPassWord\" class=\"sr-only\">Password</label>
                    <input type=\"password\" id=\"inputPassWord\" name=\"passWord\" class=\"form-control mt-3\" placeholder=\"Password\" required>
                    <button class=\"btn btn-lg btn-primary btn-block mt-5\" type=\"submit\">登陆</button>
                </div>
            </div>
        </form>
        <!--欢迎交流使用 请勿删除版权-->
        <p class=\"mt-4 mb-3 text-muted\">
            Powered By <a href=\"https://github.com/eyunzhu/vatfs\" class=\"text-muted\" target=\"_blank\">vatfs</a>.
            Copyright 2019 <a href=\"http://eyunzhu.com\" class=\"text-muted\" target=\"_blank\">忆云竹</a> All rights Reserved.
        </p>
    </div>
</body>
<script src=\"";
        // line 55
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/jquery2.1.4.min.js\"></script>
<script src=\"";
        // line 56
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/common.js\"></script>
<script>
    ";
        // line 58
        if (0 === twig_compare(($context["loginStatus"] ?? null), "error")) {
            // line 59
            echo "    swal(
        '登陆失败',
        '账号密码错误',
        'error'
    );
    ";
        }
        // line 65
        echo "    function judge() {
        userName = \$(\"#inputUserName\").val();
        passWord = \$(\"#inputPassWord\").val();

        if(userName.length >=5 && passWord.length>=5){
            return true;
        }else {
            swal(
                '登陆失败',
                '账号密码不得少于5位',
                'warning'
            );
            return false;
        }
    }
</script>
</html>
";
    }

    public function getTemplateName()
    {
        return "login.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 65,  133 => 59,  131 => 58,  126 => 56,  122 => 55,  98 => 33,  90 => 31,  88 => 30,  82 => 29,  73 => 23,  69 => 22,  60 => 16,  56 => 15,  50 => 12,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "login.html", "/www/wwwroot/v.amonetwork.com/public/view/vatfs/default/admin/index/login.html");
    }
}
