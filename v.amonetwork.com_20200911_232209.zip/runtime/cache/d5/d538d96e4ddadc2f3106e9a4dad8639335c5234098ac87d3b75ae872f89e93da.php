<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* search.html */
class __TwigTemplate_a803b3720a98534e40f1a23dadf3107c30585db2aab9df7ca9ecb3405479159f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
<head>
    <title>";
        // line 4
        echo twig_escape_filter($this->env, (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4["title"] ?? null) : null), "html", null, true);
        echo "</title>
    <meta charset=\"UTF-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"keywords\" content=\"";
        // line 7
        echo twig_escape_filter($this->env, (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = (($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["meta"] ?? null) : null)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144["keywords"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"description\" content=\"";
        // line 8
        echo twig_escape_filter($this->env, (($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4["meta"] ?? null) : null)) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002["description"] ?? null) : null), "html", null, true);
        echo "\">
    <meta name=\"author\" content=\"阿莫\" />
    <meta name=\"copyright\" content=\"Copyright 2020 阿莫 All rights Reserved\" />
    <link rel=\"shortcut icon\" href=\"favicon.ico\" />

    <link href=\"/static/bootstrap/dist/css/bootstrap.css\" rel=\"stylesheet\">
    <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/css/style-v.css\">
    <script src=\"";
        // line 15
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/jquery2.1.4.min.js\"></script>
</head>
<body>
    <nav class=\"navbar navbar-expand-lg navbar-dark shadow-sm rounded nice-nav\">
        <div class=\"container\"><a class=\"navbar-dark logo\" href=\"/\" style=\"color: #000000;\">
            <img src=\"";
        // line 20
        echo twig_escape_filter($this->env, (($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666["logo"] ?? null) : null), "html", null, true);
        echo "\" class=\"mr-2\">";
        echo twig_escape_filter($this->env, (($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e["title"] ?? null) : null), "html", null, true);
        echo "</a>
            ";
        // line 21
        if (0 === twig_compare((($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = (($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136["navRight"] ?? null) : null)) && is_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52) || $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 instanceof ArrayAccess ? ($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52["status"] ?? null) : null), true)) {
            // line 22
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, (($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 = (($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9) || $__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9 instanceof ArrayAccess ? ($__internal_d527c24a729d38501d770b40a0d25e1ce8a7f0bff897cc4f8f449ba71fcff3d9["navRight"] ?? null) : null)) && is_array($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386) || $__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386 instanceof ArrayAccess ? ($__internal_887a873a4dc3cf8bd4f99c487b4c7727999c350cc3a772414714e49a195e4386["url"] ?? null) : null), "html", null, true);
            echo "\" target=\"_blank\">";
            echo twig_escape_filter($this->env, (($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae = (($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f) || $__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f instanceof ArrayAccess ? ($__internal_25c0fab8152b8dd6b90603159c0f2e8a936a09ab76edb5e4d7bc95d9a8d2dc8f["navRight"] ?? null) : null)) && is_array($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae) || $__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae instanceof ArrayAccess ? ($__internal_f6dde3a1020453fdf35e718e94f93ce8eb8803b28cc77a665308e14bbe8572ae["name"] ?? null) : null), "html", null, true);
            echo "</a>
            ";
        }
        // line 24
        echo "        </div>
    </nav>
    <div class=\"container\">
        <form action=\"/search\" method=\"get\">
            <div class=\"row\">
                <div class=\"col-12 py-3\">
                    <div class=\"input-group my-3\">
                        <input id=\"input-kw\" required name=\"kw\" type=\"text\" class=\"form-control nice\" value=\"";
        // line 31
        echo twig_escape_filter($this->env, ($context["kw"] ?? null), "html", null, true);
        echo "\" placeholder=\"";
        echo twig_escape_filter($this->env, (((isset($context["kw"]) || array_key_exists("kw", $context))) ? (_twig_default_filter(($context["kw"] ?? null), (($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40) || $__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40 instanceof ArrayAccess ? ($__internal_f769f712f3484f00110c86425acea59f5af2752239e2e8596bcb6effeb425b40["searchPlaceholder"] ?? null) : null))) : ((($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f) || $__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f instanceof ArrayAccess ? ($__internal_98e944456c0f58b2585e4aa36e3a7e43f4b7c9038088f0f056004af41f4a007f["searchPlaceholder"] ?? null) : null))), "html", null, true);
        echo "\" aria-describedby=\"button-addon2\">
                        <div class=\"input-group-append\">
                            <button class=\"btn btn-dark px-1 play border-0\" type=\"submit\"><img src=\"";
        // line 33
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/search.png\"  height=\"24\"></button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <div style=\"font-size: 14px;color:#697389\">tips:
            ";
        // line 41
        echo "            ";
        echo (($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 = ($context["siteBaseConfig"] ?? null)) && is_array($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760) || $__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760 instanceof ArrayAccess ? ($__internal_a06a70691a7ca361709a372174fa669f5ee1c1e4ed302b3a5b61c10c80c02760["searchTips"] ?? null) : null);
        echo "
            ";
        // line 43
        echo "        </div>
        <!--搜索结果-->
        <dev class=\"row\">
            <div  class=\"col-12\">
                <div class=\"nice-c\" style=\"font-size: 14px;color:#697389\">
                    搜索结果：共";
        // line 48
        echo twig_escape_filter($this->env, (($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce = ($context["searchResult"] ?? null)) && is_array($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce) || $__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce instanceof ArrayAccess ? ($__internal_653499042eb14fd8415489ba6fa87c1e85cff03392e9f57b26d0da09b9be82ce["total"] ?? null) : null), "html", null, true);
        echo "项 ";
        echo twig_escape_filter($this->env, (($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b = ($context["searchResult"] ?? null)) && is_array($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b) || $__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b instanceof ArrayAccess ? ($__internal_ba9f0a3bb95c082f61c9fbf892a05514d732703d52edc77b51f2e6284135900b["last_page"] ?? null) : null), "html", null, true);
        echo "页</div>
                <div id=\"urlblock1\" class=\"row mr-0\">
                    ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c = ($context["searchResult"] ?? null)) && is_array($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c) || $__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c instanceof ArrayAccess ? ($__internal_73db8eef4d2582468dab79a6b09c77ce3b48675a610afd65a1f325b68804a60c["data"] ?? null) : null));
        foreach ($context['_seq'] as $context["k"] => $context["v"]) {
            // line 51
            echo "                    <div  class=\"col-md-3 col-ms-4 col-12 pr-0 mb-0\">
                        <a href=\"detail/";
            // line 52
            echo twig_escape_filter($this->env, (($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972 = $context["v"]) && is_array($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972) || $__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972 instanceof ArrayAccess ? ($__internal_d8ad5934f1874c52fa2ac9a4dfae52038b39b8b03cfc82eeb53de6151d883972["vid"] ?? null) : null), "html", null, true);
            echo ".html\" target=\"_blank\">
                            <div style=\"margin-top: 10px;height: 100px;\">
                                <div style=\"margin-right: 9px; height: 100%;width: 76.28px;float: left;\">
                                    <div style=\"position: absolute;width: 76.28px;border-radius: 2px;color: yellow;background: #727988;font-size: 12px;\">
                                        ";
            // line 56
            echo twig_escape_filter($this->env, (($__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216 = $context["v"]) && is_array($__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216) || $__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216 instanceof ArrayAccess ? ($__internal_df39c71428eaf37baa1ea2198679e0077f3699bdd31bb5ba10d084710b9da216["label"] ?? null) : null), "html", null, true);
            echo "
                                    </div>
                                    <img data-src=\"";
            // line 58
            echo twig_escape_filter($this->env, (($__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0 = $context["v"]) && is_array($__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0) || $__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0 instanceof ArrayAccess ? ($__internal_bf0e189d688dc2ad611b50a437a32d3692fb6b8be90d2228617cfa6db44e75c0["pic"] ?? null) : null), "html", null, true);
            echo "\" src=\"\" style=\"height: 100%;width: 76.28px;background-image: url('https://pane.oss-cn-beijing.aliyuncs.com/static/project/pahei/img/bg.jpg');background-size: cover;background-position:50% 50%;\"/>
                                </div>
                                <div style=\"height: 100%;\">
                                    <div>
                                        ";
            // line 62
            echo twig_escape_filter($this->env, (($__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c = $context["v"]) && is_array($__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c) || $__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c instanceof ArrayAccess ? ($__internal_674c0abf302105af78b0a38907d86c5dd0028bdc3ee5f24bf52771a16487760c["name"] ?? null) : null), "html", null, true);
            echo "
                                    </div>
                                    <div style=\"font-size: 12px;color:#697389\">
                                        站点:<span style=\"color: red;font-size: 18px;\">";
            // line 65
            echo twig_escape_filter($this->env, (($__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f = $context["v"]) && is_array($__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f) || $__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f instanceof ArrayAccess ? ($__internal_dd839fbfcab68823c49af471c7df7659a500fe72e71b58d6b80d896bdb55e75f["siteId"] ?? null) : null), "html", null, true);
            echo "</span>
                                    </div>
                                    <div style=\"font-size: 12px;color:#697389\">
                                        ";
            // line 68
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (($__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc = $context["v"]) && is_array($__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc) || $__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc instanceof ArrayAccess ? ($__internal_a7ed47878554bdc32b70e1ba5ccc67d2302196876fbf62b4c853b20cb9e029fc["updateTime"] ?? null) : null), "y-m-d H:i:s"), "html", null, true);
            echo "
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['k'], $context['v'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 75
        echo "                </div>
            </div>
        </dev>
        <div class=\"mt-2\">
            ";
        // line 79
        $macros["imports"] = $this->macros["imports"] = $this->loadTemplate("page.html", "search.html", 79)->unwrap();
        // line 80
        echo "            ";
        echo twig_call_macro($macros["imports"], "macro_paging", [($context["page"] ?? null), ($context["max"] ?? null), (("/search/" . ($context["kw"] ?? null)) . "/"), 5], 80, $context, $this->getSourceContext());
        echo "
        </div>

        <!--欢迎交流使用 请勿删除版权-->
        <p class=\"mt-4 mb-3 text-muted text-right\">
            Powered By <a href=\"https://github.com/Amo-NetWork/Online-Player\" class=\"text-muted\" target=\"_blank\">Amo-Online-Player</a>.
            Copyright 2020 <a href=\"https://amonetwork.com\" class=\"text-muted\" target=\"_blank\">Amo_NetWork</a> All rights Reserved.
        </p>
    </div>
</body>
<script src=\"";
        // line 90
        echo twig_escape_filter($this->env, ($context["__TMPL__"] ?? null), "html", null, true);
        echo "/static/js/common.js\"></script>
<script>
    //滚动事件
    start () //打开页面 调用一次
    \$(window).on('scroll',function(){
        start () //滚动页面是 调用一次   方便管理
    })
    //加载函数
    function start (){
        \$('.container img').not('[data-isLoaded]').each(function(){
            var \$node = \$(this)
            if( isShow( \$node) ){
                //缓冲效果
                setTimeout(function(){
                    loadIng( \$node)
                },500)
            }
        })
    }
    // 页面逻辑
    function isShow(\$node){
        // 当一个元素出现在我们眼前    小于 窗口高度 加上窗口滚动的高度的时候    就意味着  到达目标点
        // 可以开始加载图片 或者其他内容
        return \$node.offset().top <= \$(window).height() + \$(window).scrollTop()
    }
    // 显示状态
    function loadIng(\$img){
        // 获取目标元素 并替换
        \$img.attr('src', \$img.attr('data-src'))
        //性能优化   进行判断   已经加载的  不会再进行加载
        \$img.attr('data-isLoaded', 1)
    }
    document.onreadystatechange = subSomething;//当页面加载状态改变的时候执行这个方法.
    function subSomething()
    {
        setTimeout(function(){
            window.scrollTo(0, 0);
        },100)
    }
    \$('input').on('blur',function(){
        window.scroll(0, 0);
        setTimeout(function(){
            window.scrollTo(0, 0)
        },100)
    })
    function hideKeyBored(){
        setTimeout(function(){
            window.scrollTo(0, 0)
            return true;
        },100)
    }
</script>
</html>";
    }

    public function getTemplateName()
    {
        return "search.html";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  207 => 90,  193 => 80,  191 => 79,  185 => 75,  172 => 68,  166 => 65,  160 => 62,  153 => 58,  148 => 56,  141 => 52,  138 => 51,  134 => 50,  127 => 48,  120 => 43,  115 => 41,  105 => 33,  98 => 31,  89 => 24,  81 => 22,  79 => 21,  73 => 20,  65 => 15,  61 => 14,  52 => 8,  48 => 7,  42 => 4,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "search.html", "/www/wwwroot/v.amonetwork.com/public/view/vatfs/default/index/index/search.html");
    }
}
